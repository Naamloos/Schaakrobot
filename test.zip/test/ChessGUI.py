from tkinter import *
import chess
import chess.engine
from PIL import Image

window = Tk()
board = chess.Board()
engine = chess.engine.SimpleEngine.popen_uci("C:/Users/trol1/AppData/Local/Programs/Python/Python38-32/Lib/site-packages/stockfish")


window.title("Chess GUI")
window.geometry('640x688')
z = 0

alphabetArray = ['a', 'b', 'c' 'd', 'e', 'f', 'g', 'h']


def switch(arg):
    switch = {
        "p": Image.open("SchaakstukkenPNGs/PionBlauw.png"),
        "P": Image.open("SchaakstukkenPNGs/PionRood.png"),
        "r": Image.open("SchaakstukkenPNGs/TorenBlauw.png"),
        "R": Image.open("SchaakstukkenPNGs/TorenRood.png"),
        "n": Image.open("SchaakstukkenPNGs/PaardBlauw.png"),
        "N": Image.open("SchaakstukkenPNGs/PaardRood.png"),
        "b": Image.open("SchaakstukkenPNGs/LoperBlauw.png"),
        "B": Image.open("SchaakstukkenPNGs/LoperRood.png"),
        "q": Image.open("SchaakstukkenPNGs/KoniningBlauw.png"),
        "Q": Image.open("SchaakstukkenPNGs/KoniningRood.png"),
        "k": Image.open("SchaakstukkenPNGs/KoningBlauw.png"),
        "K": Image.open("SchaakstukkenPNGs/KoningRood.png")
    }
    file = switch.get(arg, ".")
    return file


def sendMove(moveToSend):
    move = inputMove.get()
    board.push_san(move)
    result = engine.play(board, chess.engine.Limit(time=0.1))
    board.push(result.move)
    generateBoard()
    print(board)


def generateBoard():
    counterY = 0
    counterX = 0
    posArray = list(str(board))
    while ' ' in posArray: posArray.remove(' ')
    for x in posArray:
        if x != '\n':
            #            piecePic = switch(x)
            if x != ".":  # image = piecePic
                piece = Button(window, text=x, height=5, width=10).grid(column=counterX, row=counterY)
            else:
                piece = Button(window, text=x, height=5, width=10).grid(column=counterX, row=counterY)
            counterX = counterX + 1
        else:
            counterY = counterY + 1
            counterX = 0


# for x in range(8):
#     for y in range(8):
#         btn = Button(window, text="Click Me", height=5, width=10)
#         if y + z / 2 == 0:
#             btn.config(bg='black')
#         btn.grid(column=x, row=y)
#     z + 1
inputMove = Entry(window)
inputMove.grid(column=0, row=9)
submit = Button(window, text="send move")
submit.bind("<Button-1>", sendMove)
submit.grid(column=1, row=9)
generateBoard()
window.mainloop()
# grid = [[-1] * 8 for n in range(8)]  # list comprehension
# grid[0][0] = 1
# grid[7][7] = 1
#
# w = 70  # width of each cell
#
# GUI = tkinter.Tk()
# GUI.geometry('800x600')
#
#
# def draw():
#     x, y = 10, 10  # starting position
#
#     for row in grid:
#         for col in row:
#             if col == 1:
#                 fill(250, 0, 0)
#             else:
#                 fill(255)
#             rect(x, y, w, w)
#             x = x + w  # move right
#         y = y + w  # move down
#         x = 0  # rest to left edge
# GUI.mainloop()
